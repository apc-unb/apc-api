package goforces

//Member represents Codeforces Member
type Member struct {
	Handle string `json:"handle"`
}
